<?php
// Consultas de solo lectura: no se insertan, modifican ni eliminan datos.
if (session_status() === PHP_SESSION_NONE) session_start();
mysqli_report(MYSQLI_REPORT_OFF);
include('conexion.php');
if (!isset($conexion) || !($conexion instanceof mysqli) || mysqli_connect_errno()) {
    die('No se pudo conectar a MySQL. Revise conexion.php y la variable $conexion.');
}
mysqli_set_charset($conexion, 'utf8mb4');
function h($v) { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function filas($conexion, $sql) {
    $r = mysqli_query($conexion, $sql);
    if (!$r) {
        error_log('INAC consulta SQL: ' . mysqli_error($conexion));
        return [[], 'No se pudo completar la consulta. Revise los nombres de las tablas y columnas.'];
    }
    $datos = [];
    while ($fila = mysqli_fetch_assoc($r)) $datos[] = $fila;
    return [$datos, ''];
}
require_once('plantilla_inac.php');

list($datos, $error) = filas($conexion, <<<'SQL'
SELECT e.NIE, e.Nombre_Estudiante, s.Nombre_Seccion,
       (SELECT COUNT(*) FROM Control c WHERE c.NIE=e.NIE) AS Incidentes,
       (SELECT COUNT(*) FROM Control c JOIN Control_Falta cf ON cf.ID_Control=c.ID_Control WHERE c.NIE=e.NIE) AS Total_Faltas
FROM Estudiante e
LEFT JOIN Seccion s ON s.ID_Seccion=e.ID_Seccion
ORDER BY Total_Faltas DESC, e.Nombre_Estudiante
SQL
);
inac_inicio_pagina('Consulta de faltas acumuladas', 'acumuladas');
?>
<div class="section-heading"><div><p>Conteo de faltas por estudiante, ordenado de mayor a menor.</p></div></div>
<section class="card">
<h2>Resultados de la consulta</h2>
<p class="muted">Registros encontrados: <?php echo count($datos); ?></p>
<?php if ($error): ?><div class="alert error"><?php echo h($error); ?></div><?php endif; ?>
<div class="table-wrap"><table><thead><tr><th>NIE</th><th>Estudiante</th><th>Sección</th><th>Incidencias</th><th>Faltas acumuladas</th></tr></thead><tbody>
<?php foreach ($datos as $fila): ?><tr><td><?php echo h($fila['NIE'] ?? '—'); ?></td><td><?php echo h($fila['Nombre_Estudiante'] ?? '—'); ?></td><td><?php echo h($fila['Nombre_Seccion'] ?? '—'); ?></td><td><?php echo h($fila['Incidentes'] ?? '—'); ?></td><td><?php echo h($fila['Total_Faltas'] ?? '—'); ?></td></tr><?php endforeach; ?>
<?php if (!$datos): ?><tr><td colspan="5">No hay registros para mostrar.</td></tr><?php endif; ?>
</tbody></table></div>
</section>
<?php inac_fin_pagina(); ?>
