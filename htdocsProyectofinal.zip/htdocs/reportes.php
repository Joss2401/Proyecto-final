<?php
// Consultas de solo lectura: no se insertan, modifican ni eliminan datos.
if (session_status() === PHP_SESSION_NONE) session_start();
mysqli_report(MYSQLI_REPORT_OFF);
include('conexion.php');
if (!isset($conexion) || !($conexion instanceof mysqli) || mysqli_connect_errno()) {
    die('No se pudo conectar a MySQL. Revise conexion.php y la variable $conexion.');
}
mysqli_set_charset($conexion, 'utf8mb4');
function h($v) { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function filas($conexion, $sql) {
    $r = mysqli_query($conexion, $sql);
    if (!$r) {
        error_log('INAC consulta SQL: ' . mysqli_error($conexion));
        return [[], 'No se pudo completar la consulta. Revise los nombres de las tablas y columnas.'];
    }
    $datos = [];
    while ($fila = mysqli_fetch_assoc($r)) $datos[] = $fila;
    return [$datos, ''];
}
require_once('plantilla_inac.php');

list($datos, $error) = filas($conexion, <<<'SQL'
SELECT s.Nombre_Seccion, f.NomF,
       COUNT(*) AS Total_Faltas,
       COUNT(DISTINCT c.NIE) AS Estudiantes,
       MAX(c.Fecha) AS Ultima_Fecha
FROM Control_Falta cf
JOIN Control c ON c.ID_Control=cf.ID_Control
JOIN Estudiante e ON e.NIE=c.NIE
LEFT JOIN Seccion s ON s.ID_Seccion=e.ID_Seccion
JOIN Faltas f ON f.CodF=cf.CodF
GROUP BY s.ID_Seccion, s.Nombre_Seccion, f.CodF, f.NomF
ORDER BY Total_Faltas DESC, s.Nombre_Seccion, f.NomF
SQL
);
inac_inicio_pagina('Consultas de reportes', 'reportes');
?>
<div class="section-heading"><div><p>Reporte consolidado de faltas por sección y tipo de falta.</p></div></div>
<section class="card">
<h2>Resultados de la consulta</h2>
<p class="muted">Registros encontrados: <?php echo count($datos); ?></p>
<?php if ($error): ?><div class="alert error"><?php echo h($error); ?></div><?php endif; ?>
<div class="table-wrap"><table><thead><tr><th>Sección</th><th>Tipo de falta</th><th>Total de faltas</th><th>Estudiantes involucrados</th><th>Última fecha</th></tr></thead><tbody>
<?php foreach ($datos as $fila): ?><tr><td><?php echo h($fila['Nombre_Seccion'] ?? '—'); ?></td><td><?php echo h($fila['NomF'] ?? '—'); ?></td><td><?php echo h($fila['Total_Faltas'] ?? '—'); ?></td><td><?php echo h($fila['Estudiantes'] ?? '—'); ?></td><td><?php echo h($fila['Ultima_Fecha'] ?? '—'); ?></td></tr><?php endforeach; ?>
<?php if (!$datos): ?><tr><td colspan="5">No hay registros para mostrar.</td></tr><?php endif; ?>
</tbody></table></div>
</section>
<?php inac_fin_pagina(); ?>
