
<?php
// ============================================
// SISTEMA DE CONTROL DE FALTAS ESCOLARES
// INSTITUTO NACIONAL "ALBERT CAMUS"
// CONSULTA DE FALTAS REGISTRADAS
// Archivo: registrar_falta.php
// ============================================

// Iniciar sesión
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Configuración de MySQL
mysqli_report(MYSQLI_REPORT_OFF);

// Conexión
require_once 'conexion.php';

// Verificar conexión
if (
    !isset($conexion) ||
    !($conexion instanceof mysqli) ||
    $conexion->connect_errno
) {
    die("No se pudo conectar con la base de datos.");
}

// Caracteres especiales
mysqli_set_charset($conexion, 'utf8mb4');

// Plantilla institucional
require_once 'plantilla_inac.php';

// ============================================
// FUNCIÓN PARA MOSTRAR DATOS SEGUROS
// ============================================

function limpiarConsulta($valor) {
    return htmlspecialchars(
        (string)($valor ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

// ============================================
// VARIABLES
// ============================================

$registros = [];
$error = "";
$total = 0;

// Activar diagnóstico temporal
// Cambiar a false cuando funcione correctamente
$modoDiagnostico = true;

// ============================================
// CONSULTA SQL PRINCIPAL
// ============================================

// Esta consulta utiliza las tablas:
//
// Control
// Estudiante
// Seccion
// Docente
// Control_Falta
// Faltas
//
// Se utiliza una subconsulta para obtener
// las faltas asociadas a cada control.
//
// No se usa GROUP BY en la consulta principal.

$sql = "
SELECT

    c.ID_Control,
    c.Fecha,
    c.`Observación` AS Observacion,
    c.Compromiso_Estudiante,
    c.Compromiso_PadreFamilia,
    c.NIE AS NIE,
    c.DUI AS DUI,

    e.Nombre_Estudiante,

    s.Nombre_Seccion,

    d.NombreCompleD,
    d.Cargo,

    (
        SELECT GROUP_CONCAT(
            DISTINCT f.NomF
            ORDER BY f.NomF
            SEPARATOR ', '
        )

        FROM Control_Falta AS cf

        INNER JOIN Faltas AS f
            ON cf.CodF = f.CodF

        WHERE cf.ID_Control = c.ID_Control

    ) AS Faltas_Registradas

FROM Control AS c

LEFT JOIN Estudiante AS e
    ON c.NIE = e.NIE

LEFT JOIN Seccion AS s
    ON e.ID_Seccion = s.ID_Seccion

LEFT JOIN Docente AS d
    ON c.DUI = d.DUI

ORDER BY
    c.Fecha DESC,
    c.ID_Control DESC
";

// ============================================
// EJECUTAR CONSULTA
// ============================================

$resultado = mysqli_query($conexion, $sql);

if ($resultado === false) {

    $detalleError = mysqli_error($conexion);

    // Guardar error en registro del servidor
    error_log(
        "Error en registrar_falta.php: " .
        $detalleError
    );

    if ($modoDiagnostico) {

        // Solo para identificar el problema
        $error = "ERROR SQL: " . $detalleError;

    } else {

        $error = "No se pudo cargar la consulta. "
               . "Contacte al administrador.";

    }

} else {

    while ($fila = mysqli_fetch_assoc($resultado)) {

        $registros[] = $fila;

    }

    mysqli_free_result($resultado);

    $total = count($registros);
}

// ============================================
// INICIAR PLANTILLA
// ============================================

inac_inicio_pagina(
    'Consulta de faltas registradas',
    'registro'
);

?>

<style>

/* ============================================
   ESTILOS DE CONSULTA
============================================ */

.consulta-contenedor {
    width: 100%;
}

.consulta-descripcion {
    color: #64748b;
    font-size: 14px;
    margin-bottom: 25px;
}

.consulta-tarjeta {
    background: #ffffff;
    padding: 25px;
    border-radius: 14px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 4px 15px rgba(0,0,0,0.04);
}

.consulta-titulo {
    color: #0f172a;
    font-size: 20px;
    font-weight: 700;
    margin-bottom: 15px;
}

.consulta-total {
    color: #64748b;
    font-size: 14px;
    margin-bottom: 20px;
}

.consulta-buscador {
    margin-bottom: 22px;
}

.consulta-buscador label {
    display: block;
    font-weight: 600;
    margin-bottom: 10px;
    color: #0f172a;
}

.consulta-buscador input {
    width: 100%;
    max-width: 500px;
    padding: 12px 14px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    outline: none;
    font-size: 14px;
    box-sizing: border-box;
}

.consulta-buscador input:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37,99,235,0.1);
}

.consulta-tabla-contenedor {
    width: 100%;
    overflow-x: auto;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
}

.consulta-tabla {
    width: 100%;
    border-collapse: collapse;
    min-width: 1150px;
    font-size: 13px;
}

.consulta-tabla thead {
    background: #eff6ff;
}

.consulta-tabla th {
    color: #0f172a;
    font-weight: 700;
    text-align: left;
    padding: 14px 12px;
    white-space: nowrap;
}

.consulta-tabla td {
    padding: 13px 12px;
    border-top: 1px solid #e2e8f0;
    color: #334155;
    vertical-align: top;
}

.consulta-tabla tbody tr:hover {
    background: #f8fafc;
}

.consulta-falta {
    display: inline-block;
    background: #fef3c7;
    color: #92400e;
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 12px;
    line-height: 1.5;
}

.consulta-vacio {
    text-align: center;
    padding: 35px !important;
    color: #64748b;
}

.consulta-error {
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 8px;
    background: #fee2e2;
    color: #991b1b;
    border: 1px solid #fecaca;
    overflow-wrap: anywhere;
}

.consulta-exito {
    padding: 12px;
    margin-bottom: 20px;
    border-radius: 8px;
    background: #eff6ff;
    color: #1e40af;
    font-size: 13px;
}

.consulta-boton {
    padding: 10px 16px;
    background: #1e3a8a;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 13px;
}

.consulta-boton:hover {
    background: #2563eb;
}

@media (max-width: 768px) {

    .consulta-tarjeta {
        padding: 15px;
    }

    .consulta-titulo {
        font-size: 18px;
    }

}

</style>

<!-- ============================================
     ENCABEZADO
============================================ -->

<div class="consulta-contenedor">

    <div class="section-heading">

        <div>

            <h2>
                Consulta de faltas registradas
            </h2>

            <p class="consulta-descripcion">
                En esta sección se muestran las faltas
                disciplinarias registradas de los
                estudiantes del Instituto Nacional
                "Albert Camus".
            </p>

        </div>

    </div>

    <!-- TARJETA PRINCIPAL -->

    <section class="consulta-tarjeta">

        <h2 class="consulta-titulo">
            Listado de faltas disciplinarias
        </h2>

        <p class="consulta-total">

            Total de registros encontrados:

            <strong>
                <?php echo $total; ?>
            </strong>

        </p>

        <!-- ====================================
             MOSTRAR ERRORES
        ==================================== -->

        <?php if (!empty($error)): ?>

            <div class="consulta-error">

                <strong>
                    No se pudo realizar la consulta.
                </strong>

                <p>
                    <?php echo limpiarConsulta($error); ?>
                </p>

            </div>

        <?php endif; ?>

        <!-- ====================================
             BUSCADOR
        ==================================== -->

        <div class="consulta-buscador">

            <label for="buscarRegistro">
                Buscar registro:
            </label>

            <input
                type="text"
                id="buscarRegistro"
                placeholder="Buscar por estudiante, NIE, docente o falta..."
                oninput="filtrarRegistros()"
            >

        </div>

        <!-- ====================================
             TABLA
        ==================================== -->

        <div class="consulta-tabla-contenedor">

            <table
                class="consulta-tabla"
                id="tablaRegistros"
            >

                <thead>

                    <tr>

                        <th>ID Registro</th>
                        <th>Fecha</th>
                        <th>Estudiante</th>
                        <th>NIE</th>
                        <th>Sección</th>
                        <th>Docente</th>
                        <th>Faltas cometidas</th>
                        <th>Observación</th>
                        <th>Compromiso estudiante</th>
                        <th>Compromiso padre de familia</th>

                    </tr>

                </thead>

                <tbody>

                <?php if (!empty($registros)): ?>

                    <?php foreach ($registros as $fila): ?>

                        <tr class="fila-registro">

                            <!-- ID -->

                            <td>
                                <?php
                                echo limpiarConsulta(
                                    $fila['ID_Control']
                                );
                                ?>
                            </td>

                            <!-- FECHA -->

                            <td>
                                <?php
                                echo limpiarConsulta(
                                    $fila['Fecha']
                                );
                                ?>
                            </td>

                            <!-- ESTUDIANTE -->

                            <td>
                                <?php
                                echo limpiarConsulta(
                                    $fila['Nombre_Estudiante']
                                    ?: 'No disponible'
                                );
                                ?>
                            </td>

                            <!-- NIE -->

                            <td>
                                <?php
                                echo limpiarConsulta(
                                    $fila['NIE']
                                );
                                ?>
                            </td>

                            <!-- SECCIÓN -->

                            <td>
                                <?php
                                echo limpiarConsulta(
                                    $fila['Nombre_Seccion']
                                    ?: 'No asignada'
                                );
                                ?>
                            </td>

                            <!-- DOCENTE -->

                            <td>
                                <?php
                                echo limpiarConsulta(
                                    $fila['NombreCompleD']
                                    ?: 'No disponible'
                                );
                                ?>
                            </td>

                            <!-- FALTAS -->

                            <td>

                                <span class="consulta-falta">

                                    <?php
                                    echo limpiarConsulta(
                                        $fila['Faltas_Registradas']
                                        ?: 'Sin faltas asociadas'
                                    );
                                    ?>

                                </span>

                            </td>

                            <!-- OBSERVACIÓN -->

                            <td>
                                <?php
                                echo limpiarConsulta(
                                    $fila['Observacion']
                                    ?: 'Sin observaciones'
                                );
                                ?>
                            </td>

                            <!-- COMPROMISO ESTUDIANTE -->

                            <td>
                                <?php
                                echo limpiarConsulta(
                                    $fila['Compromiso_Estudiante']
                                    ?: 'Sin compromiso'
                                );
                                ?>
                            </td>

                            <!-- COMPROMISO PADRE -->

                            <td>
                                <?php
                                echo limpiarConsulta(
                                    $fila['Compromiso_PadreFamilia']
                                    ?: 'Sin compromiso'
                                );
                                ?>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td
                            colspan="10"
                            class="consulta-vacio"
                        >

                            <?php if (!empty($error)): ?>

                                No fue posible cargar los registros.

                            <?php else: ?>

                                No hay faltas registradas
                                en la base de datos.

                            <?php endif; ?>

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

        <!-- MENSAJE DE BÚSQUEDA -->

        <p
            id="mensajeBusqueda"
            style="
                display:none;
                text-align:center;
                color:#64748b;
                padding:20px;
            "
        >
            No se encontraron registros
            con esa búsqueda.
        </p>

    </section>

</div>

<!-- ============================================
     JAVASCRIPT PARA BUSCAR REGISTROS
============================================ -->

<script>

function filtrarRegistros() {

    const buscador =
        document.getElementById("buscarRegistro");

    const texto =
        buscador.value.toLowerCase().trim();

    const filas =
        document.querySelectorAll(".fila-registro");

    let encontrados = 0;

    filas.forEach(function(fila) {

        const contenido =
            fila.textContent.toLowerCase();

        if (contenido.includes(texto)) {

            fila.style.display = "";
            encontrados++;

        } else {

            fila.style.display = "none";

        }

    });

    const mensaje =
        document.getElementById("mensajeBusqueda");

    if (filas.length > 0 && encontrados === 0) {

        mensaje.style.display = "block";

    } else {

        mensaje.style.display = "none";

    }

}

</script>

<?php

// Cerrar plantilla institucional
inac_fin_pagina();

?>
