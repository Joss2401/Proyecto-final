
<?php
// ==========================================
// PLANTILLA GENERAL - SISTEMA DE FALTAS INAC
// ==========================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar que el usuario haya iniciado sesión
if (
    !isset($_SESSION['id_usuario']) ||
    !isset($_SESSION['rol'])
) {
    header('Location: Faltas_Login.php');
    exit;
}

// Roles permitidos en el sistema
$rolesPermitidos = ['administrador', 'docente'];

if (!in_array($_SESSION['rol'], $rolesPermitidos, true)) {
    header('Location: Faltas_Logout.php');
    exit;
}

function inac_inicio_pagina($titulo, $activo) {

    // ======================================
    // INFORMACIÓN DEL USUARIO
    // ======================================

    $etiquetasRoles = [
        'administrador' => 'Administrador',
        'docente' => 'Docente Guía / Reportante'
    ];

    $rol = (string)($_SESSION['rol'] ?? '');

    $nombre = $etiquetasRoles[$rol] ?? 'Usuario';

    $subtitulo = $rol === 'administrador'
        ? 'Administración'
        : 'Personal autorizado';

    // Obtener iniciales del usuario
    $partes = preg_split('/\s+/', trim($nombre));

    $iniciales = '';

    foreach (array_slice($partes, 0, 2) as $parte) {

        if ($parte !== '') {

            $iniciales .= function_exists('mb_substr')
                ? mb_strtoupper(
                    mb_substr($parte, 0, 1, 'UTF-8'),
                    'UTF-8'
                )
                : strtoupper(substr($parte, 0, 1));
        }
    }

    // ======================================
    // MENÚ DE NAVEGACIÓN
    // ======================================

    $rutas = [
        [
            'Faltas_Inicio.php',
            '🏠',
            'Inicio',
            'inicio'
        ],
        [
            'Agregar_Estudiante.php',
            '👤',
            'Agregar estudiante',
            'estudiantes'
        ],
        [
            'Registro_Faltas_INAC.php',
            '📋',
            'Registrar faltas',
            'registrar'
        ],
        [
            'registrar_falta.php',
            '🗂️',
            'Consulta de faltas registradas',
            'registro'
        ],
        [
            'expediente.php',
            '🗂️',
            'Consulta de expedientes',
            'expediente'
        ],
        [
            'reportes.php',
            '🗂️',
            'Consultas de reportes',
            'reportes'
        ],
        [
            'faltas_acumuladas.php',
            '🗂️',
            'Consulta de faltas acumuladas',
            'acumuladas'
        ]
    ];

    // ======================================
    // OPCIÓN EXCLUSIVA DEL ADMINISTRADOR
    // ======================================

    if ($rol === 'administrador') {

        // Agregar docente en la posición original
        array_splice($rutas, 2, 0, [[
            'Agregar_Docente.php',
            '👥',
            'Agregar docente',
            'docente'
        ]]);

    }

    // Función para proteger textos HTML
    $h = function($valor) {
        return htmlspecialchars(
            (string)$valor,
            ENT_QUOTES,
            'UTF-8'
        );
    };

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <?= $h($titulo) ?> | Sistema de Control de Faltas
    </title>

    <link
        rel="stylesheet"
        href="estilos_consultas.css?v=20261020-3"
    >

    <style>

        <?php
        $archivoCSS = __DIR__ . '/estilos_consultas.css';

        if (is_readable($archivoCSS)) {
            echo file_get_contents($archivoCSS);
        }
        ?>

        /* Ajustes generales de la plantilla */

        .layout {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            flex-shrink: 0;
        }

        .main {
            flex: 1;
            min-width: 0;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
        }

        .top-actions {
            display: flex;
            align-items: center;
            gap: 18px;
            margin-left: auto;
        }

        .inac-search {
            display: flex;
            align-items: center;
            gap: 10px;
            width: 270px;
            height: 39px;
            padding: 0 13px;
            border: 1px solid #cbd5e1;
            border-radius: 7px;
            background: #fff;
            color: #637a9e;
        }

        .inac-search input {
            width: 100%;
            min-width: 0;
            border: none;
            outline: none;
            background: transparent;
            color: #0f172a;
            font-size: 12px;
        }

        .inac-notification {
            display: grid;
            place-items: center;
            border: none;
            background: transparent;
            color: #14264b;
            padding: 5px;
        }

        .inac-notification svg {
            width: 21px;
            height: 21px;
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .profile strong {
            display: block;
        }

        .profile small {
            display: block;
            margin-top: 3px;
        }

        @media (max-width: 800px) {

            .inac-search {
                width: 190px;
            }

            .top-actions {
                flex-wrap: wrap;
            }
        }

        @media (max-width: 600px) {

            .top-actions {
                width: 100%;
                margin-left: 0;
            }

            .inac-search {
                flex: 1;
                width: auto;
            }
        }

    </style>

</head>

<body>

<div class="layout">

    <!-- ======================================
         BARRA LATERAL
    ======================================= -->

    <aside class="sidebar">

        <div class="brand">

            <div class="brand-icon">⌂</div>

            <div>

                <strong>
                    SISTEMA DE CONTROL<br>
                    DE FALTAS
                </strong>

                <small>
                    Instituto Nacional Albert Camus
                </small>

            </div>

        </div>

        <!-- MENÚ SEGÚN ROL -->

        <nav class="menu" aria-label="Menú principal">

            <?php foreach ($rutas as $ruta): ?>

                <a
                    href="<?= $h($ruta[0]) ?>"
                    class="<?= $ruta[3] === $activo ? 'activo' : '' ?>"
                >

                    <span class="nav-icon">
                        <?= $h($ruta[1]) ?>
                    </span>

                    <?= $h($ruta[2]) ?>

                </a>

            <?php endforeach; ?>

        </nav>

        <!-- PARTE INFERIOR -->

        <div class="sidebar-bottom">

            <div class="logout-wrap">

                <a
                    class="logout"
                    href="Faltas_Logout.php"
                >

                    <span class="nav-icon">🔓</span>

                    Cerrar sesión

                </a>

            </div>

            <div class="version">

                Sistema de control de faltas<br>
                © 2026 · Instituto

            </div>

        </div>

    </aside>

    <!-- ======================================
         CONTENIDO PRINCIPAL
    ======================================= -->

    <div class="main">

        <header class="topbar">

            <div>

                <div class="breadcrumb">
                    Instituto / <?= $h($titulo) ?>
                </div>

                <div class="page-title">
                    <?= $h($titulo) ?>
                </div>

            </div>

            <div class="top-actions">

                <?php if ($activo === 'inicio'): ?>

                    <!-- BUSCADOR -->

                    <label class="inac-search">

                        <span aria-hidden="true">⌕</span>

                        <input
                            id="busqueda"
                            type="search"
                            placeholder="Buscar estudiante..."
                            aria-label="Buscar estudiante"
                        >

                    </label>

                    <!-- NOTIFICACIONES -->

                    <span
                        class="inac-notification"
                        title="Notificaciones"
                    >

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                        >

                            <path
                                d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"
                            />

                            <path d="M10 21h4"/>

                        </svg>

                    </span>

                <?php endif; ?>

                <!-- PERFIL DEL USUARIO -->

                <div class="profile">

                    <div class="avatar">
                        <?= $h($iniciales) ?>
                    </div>

                    <div>

                        <strong>
                            <?= $h($nombre) ?>
                        </strong>

                        <small>
                            <?= $h($subtitulo) ?>
                        </small>

                    </div>

                </div>

            </div>

        </header>

        <main class="content">

<?php
}

// ==========================================
// CERRAR ESTRUCTURA DE LA PLANTILLA
// ==========================================

function inac_fin_pagina() {

    echo '</main></div></div></body></html>';

}
?>
