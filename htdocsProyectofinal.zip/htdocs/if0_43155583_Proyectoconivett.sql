-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: sql102.infinityfree.com
-- Tiempo de generación: 26-10-2026 a las 11:01:34
-- Versión del servidor: 11.4.13-MariaDB
-- Versión de PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `if0_43155583_Proyectoconivett`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Asignación`
--

CREATE TABLE `Asignación` (
  `CodAsignacion` int(8) NOT NULL,
  `Descripcion` varchar(200) NOT NULL,
  `Tiempo` time NOT NULL,
  `Fecha` date NOT NULL,
  `ID_Control` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `Asignación`
--

INSERT INTO `Asignación` (`CodAsignacion`, `Descripcion`, `Tiempo`, `Fecha`, `ID_Control`) VALUES
(1, 'Reunión con padre de familia', '08:00:00', '2026-01-10', 1),
(2, 'Seguimiento de conducta', '09:00:00', '2026-01-12', 2),
(3, 'Orientación estudiantil', '10:00:00', '2026-01-15', 3),
(4, 'Revisión de tareas', '08:30:00', '2026-01-18', 4),
(5, 'Citación al responsable', '09:30:00', '2026-01-20', 5),
(6, 'Compromiso disciplinario', '10:30:00', '2026-01-22', 6),
(7, 'Entrevista con estudiante', '11:00:00', '2026-01-25', 7),
(8, 'Revisión de asistencia', '08:15:00', '2026-01-28', 8),
(9, 'Seguimiento académico', '09:15:00', '2026-02-01', 9),
(10, 'Reunión de orientación', '10:15:00', '2026-02-03', 10),
(11, 'Evaluación de conducta', '11:15:00', '2026-02-05', 11),
(12, 'Citación por inasistencia', '08:45:00', '2026-02-08', 12),
(13, 'Acuerdo de responsabilidad', '09:45:00', '2026-02-10', 13),
(14, 'Reunión con encargado', '10:45:00', '2026-02-12', 14),
(15, 'Control de cumplimiento', '11:30:00', '2026-02-15', 15),
(16, 'Orientación familiar', '08:20:00', '2026-02-18', 16),
(17, 'Revisión de compromisos', '09:20:00', '2026-02-20', 17),
(18, 'Entrevista de seguimiento', '10:20:00', '2026-02-22', 18),
(19, 'Revisión de normas escolares', '11:20:00', '2026-02-25', 19),
(20, 'Evaluación de acuerdos', '12:00:00', '2026-02-28', 20),
(21, 'lo pondremos a barrer durante unas 5 horas aproximadamente en todo el instituto', '05:00:00', '2026-10-30', 22),
(22, 'lo pondremos a barrer durante unas 5 horas aproximadamente en todo el instituto', '05:00:00', '2026-10-30', 23),
(23, 'i', '05:00:00', '2026-10-31', 24),
(24, 'i', '05:00:00', '2026-10-31', 25),
(25, 'lito', '03:00:00', '2026-10-27', 26),
(26, 'Se le dejara como trabajo voluntario que ayude con la limpieza de zonas verdes en la institución', '08:00:00', '2026-10-28', 27);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Control`
--

CREATE TABLE `Control` (
  `ID_Control` int(8) NOT NULL,
  `Fecha` date NOT NULL,
  `Observación` varchar(200) NOT NULL,
  `Compromiso_Estudiante` varchar(200) NOT NULL,
  `Compromiso_PadreFamilia` varchar(200) NOT NULL,
  `NIE` int(8) NOT NULL,
  `DUI` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `Control`
--

INSERT INTO `Control` (`ID_Control`, `Fecha`, `Observación`, `Compromiso_Estudiante`, `Compromiso_PadreFamilia`, `NIE`, `DUI`) VALUES
(1, '2026-01-10', 'Llegada tardía a clases', 'Llegar temprano', 'Supervisar horario', 10293847, 2345678),
(2, '2026-01-12', 'Ausencia injustificada', 'Asistir diariamente', 'Justificar ausencias', 10293848, 3456789),
(3, '2026-01-15', 'Uniforme incompleto', 'Portar uniforme completo', 'Verificar uniforme', 10293849, 4567890),
(4, '2026-01-18', 'Incumplimiento de tareas', 'Entregar tareas pendientes', 'Revisar tareas', 10293850, 5678901),
(5, '2026-01-20', 'Uso del celular', 'Evitar celular en clase', 'Orientar al estudiante', 10293851, 6789012),
(6, '2026-01-22', 'Falta de respeto', 'Respetar a los docentes', 'Reforzar valores', 10293852, 7890123),
(7, '2026-01-25', 'Interrupción de clases', 'Mantener disciplina', 'Conversar sobre conducta', 10293853, 8901234),
(8, '2026-01-28', 'Falta de materiales', 'Llevar materiales', 'Preparar materiales', 10293854, 9012345),
(9, '2026-02-01', 'Salir sin permiso', 'Solicitar autorización', 'Dar seguimiento', 10293855, 10123456),
(10, '2026-02-03', 'Daño al mobiliario', 'Cuidar instalaciones', 'Promover responsabilidad', 10293856, 11234567),
(11, '2026-02-05', 'Conducta inapropiada', 'Mejorar comportamiento', 'Dialogar en familia', 10293857, 12345678),
(12, '2026-02-08', 'No portar carnet', 'Llevar carnet diario', 'Verificar carnet', 10293858, 13456789),
(13, '2026-02-10', 'Desobediencia', 'Cumplir indicaciones', 'Reforzar normas', 10293859, 14567890),
(14, '2026-02-12', 'Agresión verbal', 'Usar lenguaje respetuoso', 'Dar orientación', 10293860, 15678901),
(15, '2026-02-15', 'Falta de tareas', 'Organizar actividades', 'Revisar cuadernos', 10293861, 16789012),
(16, '2026-02-18', 'Llegada tardía', 'Cumplir horario', 'Asegurar puntualidad', 10293862, 17890123),
(17, '2026-02-20', 'Ausencia injustificada', 'Asistir regularmente', 'Presentar justificación', 10293863, 18901234),
(18, '2026-02-22', 'Uniforme incorrecto', 'Usar uniforme adecuado', 'Preparar uniforme', 10293864, 19012345),
(19, '2026-02-25', 'Interrupción de clases', 'Participar ordenadamente', 'Dar seguimiento', 10293865, 20123456),
(20, '2026-02-28', 'Incumplimiento de normas', 'Respetar el reglamento', 'Apoyar el cumplimiento', 10293866, 21234567),
(22, '2026-10-24', 'no llega', 'llevar siempre', 'hacerlo llegar', 19718406, 4567890),
(23, '2026-10-24', 'no llega', 'llevar siempre', 'hacerlo llegar', 19718406, 4567890),
(24, '2026-10-23', 'h', 'o', 'l', 10293855, 11234567),
(25, '2026-10-23', 'h', 'o', 'l', 10293855, 11234567),
(26, '2026-10-23', 'p', 'a', 'b', 10293851, 2345678),
(27, '2026-10-23', 'El estudiante últimamente ha estado recibiendo llamados de atención que se le han hecho por el corte de cabello inadecuado, de igual manera no porta el uniforme correctamente y llega tarde', 'El estudiante se compromete a cambiar su corte de cabello, portar bien el uniforme y llegar mas temprano a la institución', 'El padre se compromete a verificar que su hijo si cumpla con lo requerido y a estar mas pendiente para que se hijo cambie', 10293847, 13456789);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Control_Falta`
--

CREATE TABLE `Control_Falta` (
  `ID_Control` int(8) NOT NULL,
  `CodF` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `Control_Falta`
--

INSERT INTO `Control_Falta` (`ID_Control`, `CodF`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16),
(22, 3),
(23, 3),
(24, 1),
(25, 1),
(26, 1),
(27, 2),
(27, 7),
(27, 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Docente`
--

CREATE TABLE `Docente` (
  `DUI` int(10) NOT NULL,
  `NombreCompleD` varchar(100) NOT NULL,
  `Cargo` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `Docente`
--

INSERT INTO `Docente` (`DUI`, `NombreCompleD`, `Cargo`) VALUES
(2345678, 'Licda. Jacqueline J. de Vásquez', 'Directora Única'),
(3456789, 'Lic. Roberto Carlos Preza Díaz', 'Subdirector Matutino'),
(4567890, 'Prof. Mauricio Girón Salgado', 'Subdirector Vesperti'),
(5678901, 'Licda. Nurian Judith Ortiz Quintanilla', 'Coordinadora Académi'),
(6789012, 'Lic. Carlos Humberto Martínez', 'Docente Guía'),
(7890123, 'Profra. Ana María Hernández', 'Docente de Planta'),
(8901234, 'Lic. Francisco Ernesto Ramírez', 'Docente Guía'),
(9012345, 'Profr. José Luis Menjívar', 'Docente de Planta'),
(10123456, 'Licda. Carmen Elena Flores', 'Orientadora'),
(11234567, 'Lic. Francisco Javier Rivas', 'Docente Guía'),
(12345678, 'Profra. María de los Ángeles Pineda', 'Docente de Planta'),
(13456789, 'Lic. Walter Alexander Portillo', 'Docente de Planta'),
(14567890, 'Licda. Sandra Patricia Alfaro', 'Orientadora'),
(15678901, 'Profr. René Antonio Galdámez', 'Docente Guía'),
(16789012, 'Licda. Beatriz Adriana Meléndez', 'Docente de Planta'),
(17890123, 'Lic. Saúl Edgardo Orellana', 'Docente Guía'),
(18901234, 'Profra. Claudia Marcela Cruz', 'Docente de Planta'),
(19012345, 'Lic. Nelson Bladimir Escobar', 'Docente de Planta'),
(20123456, 'Licda. Gabriela Esmeralda Sermeño', 'Orientadora'),
(21234567, 'Profr. Oscar Armando Benítez', 'Docente Guía'),
(21345657, 'Mario alberto', 'Guia'),
(90547803, 'Patricio Franchezco Torres Figueroa', 'Docente guía');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Estudiante`
--

CREATE TABLE `Estudiante` (
  `NIE` int(100) NOT NULL,
  `Nombre_Estudiante` varchar(100) NOT NULL,
  `ID_Seccion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `Estudiante`
--

INSERT INTO `Estudiante` (`NIE`, `Nombre_Estudiante`, `ID_Seccion`) VALUES
(10293847, 'Alejandro José Martínez Pérez', 1),
(10293848, 'Beatriz Adriana Gómez Rivas', 2),
(10293849, 'Carlos Alberto Menjívar Orellana', 3),
(10293850, 'Diana Marcela Flores Cruz', 4),
(10293851, 'Eduardo Ernesto Portillo Galdámez', 5),
(10293852, 'Fatima Gabriela Sermeño Benítez', 6),
(10293853, 'Gabriel Alexander Pineda Meléndez', 7),
(10293854, 'Hannah Sofía Rivas Escobar', 8),
(10293855, 'Iván de Jesús Hernández Alfaro', 9),
(10293856, 'Jazmín Abigail Cruz Martínez', 10),
(10293857, 'Kevin Bladimir Morales Granados', 11),
(10293858, 'Lucía María Vásquez Turcios', 12),
(10293859, 'Mauricio Antonio Zelaya Romero', 13),
(10293860, 'Natalia Nicole Quinteros Landaverde', 14),
(10293861, 'Óscar Daniel Amaya Guardado', 15),
(10293862, 'Paola Michelle Sandoval Henríquez', 16),
(10293863, 'Quintín Alberto Duarte Castellanos', 17),
(10293864, 'Rosa María Coto Bonilla', 18),
(10293865, 'Samuel Isaac Vides Guevara', 19),
(10293866, 'Tatiana Vanessa Molina Zepeda', 20),
(19718406, 'Carlos', 14);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Faltas`
--

CREATE TABLE `Faltas` (
  `CodF` int(11) NOT NULL,
  `NomF` varchar(200) NOT NULL,
  `CodTip` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `Faltas`
--

INSERT INTO `Faltas` (`CodF`, `NomF`, `CodTip`) VALUES
(1, 'Escenas amorosas', 1),
(2, 'Recorte de cabello inadecuado', 2),
(3, 'Faltas continuas a clases', 3),
(4, 'Mancha paredes, pupitres, etc.', 4),
(5, 'Platica o genera desorden en clases', 5),
(6, 'Utiliza vocabulario soez', 6),
(7, 'No porta correctamente el uniforme', 7),
(8, 'Se distrae en clases por utilizar el celular', 8),
(9, 'Uso del maquillaje', 9),
(10, 'Se presenta tarde a clases de forma continua', 10),
(11, 'Se escapa o no entra a clases', 11),
(12, 'No entrega tareas', 12),
(13, 'Consume chicle en clases', 13),
(14, 'No respeta pertenencias ajenas', 14),
(15, 'Irrespeta al docente', 15),
(16, 'Falda corta', 16);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Seccion`
--

CREATE TABLE `Seccion` (
  `ID_Seccion` int(8) NOT NULL,
  `Nombre_Seccion` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `Seccion`
--

INSERT INTO `Seccion` (`ID_Seccion`, `Nombre_Seccion`) VALUES
(1, '2° Año General '),
(2, '1° Año General '),
(3, '2° Año Contadur'),
(4, '1° Año Sistemas'),
(5, '3° Año Software'),
(6, '2° Año General '),
(7, '1° Año General '),
(8, '2° Año Mercadeo'),
(9, '3° Año Contadur'),
(10, '1° Año General '),
(11, '2° Año Sistemas'),
(12, '1° Año General '),
(13, '2° Año General '),
(14, '3° Año Software'),
(15, '1° Año Contadur'),
(16, '2° Año Mercadeo'),
(17, '1° Año Sistemas'),
(18, '2° Año General '),
(19, '3° Año Contadur'),
(20, '1° Año General ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `TipoF`
--

CREATE TABLE `TipoF` (
  `CodTip` int(8) NOT NULL,
  `Nombre_Tipo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `TipoF`
--

INSERT INTO `TipoF` (`CodTip`, `Nombre_Tipo`) VALUES
(1, 'Falta leve'),
(2, 'Falta grave'),
(3, 'Falta muy grave'),
(4, 'Ausencia injustificada'),
(5, 'Llegada tardía'),
(6, 'Uniforme incorrecto'),
(7, 'Falta de respeto'),
(8, 'Incumplimiento de tareas'),
(9, 'Uso del celular'),
(10, 'Interrupción de clases'),
(11, 'Daño al mobiliario'),
(12, 'Conducta inapropiada'),
(13, 'Salir sin permiso'),
(14, 'No portar carnet'),
(15, 'Desobediencia'),
(16, 'Agresión verbal'),
(17, 'Agresión física'),
(18, 'Falta de materiales'),
(19, 'Inasistencia a actividades'),
(20, 'Reincidencia disciplinaria');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `rol` enum('administrador','docente','subdirector','orientador','directora') NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `estado` enum('activo','inactivo') NOT NULL DEFAULT 'activo',
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `rol`, `contrasena`, `estado`, `fecha_creacion`) VALUES
(1, 'administrador', '$2y$12$ws9QpgOxQvvce0mX03wR9u28jPBEH4OwbtjfA0TTdHmqRiz8nS7vW', 'activo', '2026-10-20 22:30:47'),
(2, 'docente', '$2y$12$Jk7CtJP8VmlidTHBeUmIu.uLCPqEGPx6r77WIvaJfy1y7QUR9AMiW', 'activo', '2026-10-20 23:04:13');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Asignación`
--
ALTER TABLE `Asignación`
  ADD PRIMARY KEY (`CodAsignacion`),
  ADD KEY `ID_Control` (`ID_Control`);

--
-- Indices de la tabla `Control`
--
ALTER TABLE `Control`
  ADD PRIMARY KEY (`ID_Control`),
  ADD KEY `NIE` (`NIE`),
  ADD KEY `DUI` (`DUI`);

--
-- Indices de la tabla `Control_Falta`
--
ALTER TABLE `Control_Falta`
  ADD KEY `ID_Control` (`ID_Control`),
  ADD KEY `CodF` (`CodF`);

--
-- Indices de la tabla `Docente`
--
ALTER TABLE `Docente`
  ADD PRIMARY KEY (`DUI`);

--
-- Indices de la tabla `Estudiante`
--
ALTER TABLE `Estudiante`
  ADD PRIMARY KEY (`NIE`),
  ADD KEY `fk_seccion_estudiante_inac` (`ID_Seccion`);

--
-- Indices de la tabla `Faltas`
--
ALTER TABLE `Faltas`
  ADD PRIMARY KEY (`CodF`),
  ADD KEY `CodTip` (`CodTip`);

--
-- Indices de la tabla `Seccion`
--
ALTER TABLE `Seccion`
  ADD PRIMARY KEY (`ID_Seccion`);

--
-- Indices de la tabla `TipoF`
--
ALTER TABLE `TipoF`
  ADD PRIMARY KEY (`CodTip`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `rol` (`rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Asignación`
--
ALTER TABLE `Asignación`
  MODIFY `CodAsignacion` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de la tabla `Control`
--
ALTER TABLE `Control`
  MODIFY `ID_Control` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de la tabla `Faltas`
--
ALTER TABLE `Faltas`
  MODIFY `CodF` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `Seccion`
--
ALTER TABLE `Seccion`
  MODIFY `ID_Seccion` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `TipoF`
--
ALTER TABLE `TipoF`
  MODIFY `CodTip` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `Asignación`
--
ALTER TABLE `Asignación`
  ADD CONSTRAINT `Asignación_ibfk_1` FOREIGN KEY (`ID_Control`) REFERENCES `Control` (`ID_Control`);

--
-- Filtros para la tabla `Control`
--
ALTER TABLE `Control`
  ADD CONSTRAINT `Control_ibfk_1` FOREIGN KEY (`NIE`) REFERENCES `Estudiante` (`NIE`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `Control_ibfk_2` FOREIGN KEY (`DUI`) REFERENCES `Docente` (`DUI`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `Control_Falta`
--
ALTER TABLE `Control_Falta`
  ADD CONSTRAINT `Control_Falta_ibfk_2` FOREIGN KEY (`CodF`) REFERENCES `Faltas` (`CodF`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Control_Falta_ibfk_3` FOREIGN KEY (`ID_Control`) REFERENCES `Control` (`ID_Control`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `Estudiante`
--
ALTER TABLE `Estudiante`
  ADD CONSTRAINT `fk_estudiante_seccion` FOREIGN KEY (`ID_Seccion`) REFERENCES `Seccion` (`ID_Seccion`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_seccion_estudiante_inac` FOREIGN KEY (`ID_Seccion`) REFERENCES `Seccion` (`ID_Seccion`);

--
-- Filtros para la tabla `Faltas`
--
ALTER TABLE `Faltas`
  ADD CONSTRAINT `Faltas_ibfk_1` FOREIGN KEY (`CodTip`) REFERENCES `TipoF` (`CodTip`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
