<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['id_usuario'])) {
    header('Location: Faltas_Login.php');
    exit;
}

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/plantilla_inac.php';

if (!isset($conexion) || !($conexion instanceof mysqli) || $conexion->connect_error) {
    die('No se pudo establecer la conexión con la base de datos.');
}
$conexion->set_charset('utf8mb4');

if (empty($_SESSION['csrf_docente'])) {
    $_SESSION['csrf_docente'] = bin2hex(random_bytes(32));
}

function docente_esc($texto) {
    return htmlspecialchars((string)$texto, ENT_QUOTES, 'UTF-8');
}

$mensaje = '';
$tipo = '';
$dui = '';
$nombre = '';
$cargo = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dui = trim((string)($_POST['dui'] ?? ''));
    $nombre = trim((string)($_POST['nombre'] ?? ''));
    $cargo = trim((string)($_POST['cargo'] ?? ''));
    $token = (string)($_POST['csrf_token'] ?? '');

    if (!hash_equals($_SESSION['csrf_docente'], $token)) {
        $mensaje = 'La sesión del formulario ha caducado. Actualice la página e inténtelo nuevamente.';
        $tipo = 'error';
    } elseif ($dui === '' || $nombre === '' || $cargo === '') {
        $mensaje = 'Complete todos los campos obligatorios.';
        $tipo = 'error';
    } elseif (!preg_match('/^[0-9]{8}-[0-9]$/', $dui)) {
        $mensaje = 'El DUI debe tener el formato 00000000-0.';
        $tipo = 'error';
    } elseif (mb_strlen($nombre) > 200 || mb_strlen($cargo) > 100) {
        $mensaje = 'El nombre o el cargo excede la longitud permitida por este formulario.';
        $tipo = 'error';
    } else {
        $consulta = $conexion->prepare('SELECT DUI FROM Docente WHERE DUI = ? LIMIT 1');
        if (!$consulta) {
            $mensaje = 'No se pudo comprobar el DUI. Revise la estructura de la tabla Docente.';
            $tipo = 'error';
        } else {
            $consulta->bind_param('s', $dui);
            $consulta->execute();
            $consulta->store_result();
            $existe = $consulta->num_rows > 0;
            $consulta->close();

            if ($existe) {
                $mensaje = 'Ya existe un docente registrado con ese DUI.';
                $tipo = 'error';
            } else {
                $insertar = $conexion->prepare('INSERT INTO Docente (DUI, NombreCompleD, Cargo) VALUES (?, ?, ?)');
                if (!$insertar) {
                    $mensaje = 'No se pudo preparar el registro. Verifique los nombres de los campos.';
                    $tipo = 'error';
                } else {
                    $insertar->bind_param('sss', $dui, $nombre, $cargo);
                    if ($insertar->execute()) {
                        $mensaje = '¡Docente registrado correctamente!';
                        $tipo = 'exito';
                        $dui = '';
                        $nombre = '';
                        $cargo = '';
                        $_SESSION['csrf_docente'] = bin2hex(random_bytes(32));
                    } else {
                        $mensaje = 'No se pudo guardar el docente: ' . $insertar->error;
                        $tipo = 'error';
                    }
                    $insertar->close();
                }
            }
        }
    }
}

inac_inicio_pagina('Agregar docente', 'docentes');
?>
<style>
/* Estilos exclusivos del formulario; no modifican la plantilla compartida. */
.doc-formulario { max-width: 980px; margin: 0 auto; color: #0f172a; }
.doc-formulario .doc-intro { margin: 0 0 22px; color: #64748b; line-height: 1.6; }
.doc-formulario .doc-panel { background: #fff; border: 1px solid #dce5f0; border-radius: 12px; overflow: hidden; box-shadow: 0 3px 14px #172c4a08; }
.doc-formulario .doc-panel-head { display: flex; align-items: center; gap: 12px; padding: 19px 24px; border-bottom: 1px solid #edf1f6; }
.doc-formulario .doc-letra { background: #e8efff; color: #1e3a8a; font-weight: 700; padding: 10px 13px; border-radius: 8px; }
.doc-formulario .doc-panel-head h2 { margin: 0; font-size: 17px; }
.doc-formulario .doc-panel-body { padding: 25px; }
.doc-formulario .doc-campos { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 20px; }
.doc-formulario .doc-campo { min-width: 0; }
.doc-formulario .doc-ancho { grid-column: 1 / -1; }
.doc-formulario .doc-campo label { display: block; font-weight: 700; font-size: 13px; margin-bottom: 9px; }
.doc-formulario .doc-campo input { display: block; width: 100%; padding: 12px 13px; border: 1px solid #cbd5e1; border-radius: 8px; font: inherit; color: #0f172a; background: #fff; }
.doc-formulario .doc-campo input:focus { outline: none; border-color: #2563eb; box-shadow: 0 0 0 3px #dbeafe; }
.doc-formulario .doc-ayuda { color: #64748b; font-size: 12px; margin-top: 7px; }
.doc-formulario .doc-acciones { display: flex; justify-content: flex-end; gap: 12px; margin-top: 23px; flex-wrap: wrap; }
.doc-formulario .doc-boton { border-radius: 8px; padding: 12px 22px; border: 1px solid #cbd5e1; font-weight: 700; text-decoration: none; cursor: pointer; font-size: 14px; background: #fff; color: #334155; }
.doc-formulario .doc-boton-primario { background: #1e3a8a; border-color: #1e3a8a; color: #fff; }
.doc-formulario .doc-boton-primario:hover { background: #2563eb; }
.doc-formulario .doc-alerta { padding: 14px 16px; border-radius: 8px; margin-bottom: 18px; font-size: 14px; }
.doc-formulario .doc-error { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
.doc-formulario .doc-exito { background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0; }
@media (max-width: 650px) { .doc-formulario .doc-campos { grid-template-columns: 1fr; } .doc-formulario .doc-ancho { grid-column: auto; } .doc-formulario .doc-panel-body { padding: 18px; } }
</style>

<div class="doc-formulario">
    <h1 style="margin:0 0 8px;font-size:24px;color:#0f172a">Registro de docentes</h1>
    <p class="doc-intro">Complete la información del nuevo docente para incorporarlo al sistema de control de faltas escolares.</p>

    <?php if ($mensaje !== ''): ?>
        <div class="doc-alerta <?php echo $tipo === 'exito' ? 'doc-exito' : 'doc-error'; ?>" role="alert">
            <?php echo docente_esc($mensaje); ?>
        </div>
    <?php endif; ?>

    <form method="post" action="Agregar_Docente.php">
        <input type="hidden" name="csrf_token" value="<?php echo docente_esc($_SESSION['csrf_docente']); ?>">
        <section class="doc-panel">
            <div class="doc-panel-head">
                <span class="doc-letra">A</span>
                <h2>Datos del docente</h2>
            </div>
            <div class="doc-panel-body">
                <div class="doc-campos">
                    <div class="doc-campo">
                        <label for="dui">DUI del docente *</label>
                        <input id="dui" name="dui" type="text" maxlength="10" pattern="[0-9]{8}-[0-9]" inputmode="numeric" placeholder="00000000-0" value="<?php echo docente_esc($dui); ?>" required>
                        <div class="doc-ayuda">Escriba los ocho números, guion y dígito final.</div>
                    </div>
                    <div class="doc-campo">
                        <label for="cargo">Cargo *</label>
                        <input id="cargo" name="cargo" type="text" maxlength="100" placeholder="Ej. Docente Guía" value="<?php echo docente_esc($cargo); ?>" required>
                    </div>
                    <div class="doc-campo doc-ancho">
                        <label for="nombre">Nombre completo del docente *</label>
                        <input id="nombre" name="nombre" type="text" maxlength="200" placeholder="Ingrese nombres y apellidos" value="<?php echo docente_esc($nombre); ?>" required>
                    </div>
                </div>
            </div>
        </section>
        <div class="doc-acciones">
            <a href="Faltas_Inicio.php" class="doc-boton">Cancelar</a>
            <button type="submit" class="doc-boton doc-boton-primario">Guardar docente</button>
        </div>
    </form>
</div>
<?php inac_fin_pagina(); ?>
