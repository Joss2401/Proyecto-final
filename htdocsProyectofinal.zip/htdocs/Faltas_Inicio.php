
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Protección de sesión
if (!isset($_SESSION['id_usuario'])) {
    header("Location: Faltas_Login.php");
    exit;
}

// Conexión a la base de datos
require_once('conexion.php');
require_once('plantilla_inac.php');

mysqli_report(MYSQLI_REPORT_OFF);

if (!isset($conexion) || !($conexion instanceof mysqli)
    || $conexion->connect_error) {
    die('No se pudo establecer la conexión MySQL.');
}

mysqli_set_charset($conexion, 'utf8mb4');

// Escapar información
function h_inicio($valor) {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

// Obtener cantidades reales
function totalConsultaInicio($conexion, $sql) {
    $resultado = mysqli_query($conexion, $sql);

    if (!$resultado) {
        return 0;
    }

    $fila = mysqli_fetch_assoc($resultado);
    return (int)($fila['total'] ?? 0);
}

// ESTADÍSTICAS GENERALES
$totalFaltas = totalConsultaInicio(
    $conexion,
    'SELECT COUNT(*) AS total FROM `Control_Falta`'
);

$totalEstudiantes = totalConsultaInicio(
    $conexion,
    'SELECT COUNT(DISTINCT NIE) AS total FROM `Control`'
);

$totalTipos = totalConsultaInicio(
    $conexion,
    'SELECT COUNT(*) AS total FROM `Faltas`'
);

$totalDocentes = totalConsultaInicio(
    $conexion,
    'SELECT COUNT(*) AS total FROM `Docente`'
);

$estadisticas = [
    [
        'titulo' => 'Faltas registradas',
        'valor' => $totalFaltas,
        'detalle' => 'Faltas asociadas a incidencias',
        'icono' => '▤',
        'clase' => 'azul'
    ],
    [
        'titulo' => 'Estudiantes con incidencias',
        'valor' => $totalEstudiantes,
        'detalle' => 'Estudiantes con reportes registrados',
        'icono' => '♙',
        'clase' => 'amarillo'
    ],
    [
        'titulo' => 'Tipos de faltas',
        'valor' => $totalTipos,
        'detalle' => 'Faltas disponibles en el catálogo',
        'icono' => '⚠',
        'clase' => 'rojo'
    ],
    [
        'titulo' => 'Docentes registrados',
        'valor' => $totalDocentes,
        'detalle' => 'Docentes en la base de datos',
        'icono' => '♙',
        'clase' => 'azul'
    ]
];

// GRÁFICO DE LOS ÚLTIMOS SIETE MESES
$meses = [];
$valores = [];
$conteos = [];

$inicioMes = new DateTime('first day of this month');
$inicioMes->modify('-6 months');

$fechaInicio = $inicioMes->format('Y-m-d');

$sqlMeses = "
    SELECT
        DATE_FORMAT(c.Fecha, '%Y-%m') AS periodo,
        COUNT(*) AS total
    FROM `Control` c
    INNER JOIN `Control_Falta` cf
        ON cf.ID_Control = c.ID_Control
    WHERE c.Fecha >= '" .
        mysqli_real_escape_string($conexion, $fechaInicio) .
    "'
    GROUP BY DATE_FORMAT(c.Fecha, '%Y-%m')
";

$resultadoMeses = mysqli_query($conexion, $sqlMeses);

if ($resultadoMeses) {
    while ($fila = mysqli_fetch_assoc($resultadoMeses)) {
        $conteos[$fila['periodo']] = (int)$fila['total'];
    }
}

$nombresMeses = [
    'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun',
    'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'
];

for ($i = 0; $i < 7; $i++) {
    $mes = clone $inicioMes;
    $mes->modify("+$i months");

    $meses[] = $nombresMeses[(int)$mes->format('n') - 1];
    $valores[] = $conteos[$mes->format('Y-m')] ?? 0;
}

$maxGrafico = max(4, (int)ceil(max($valores) / 4) * 4);

// ÚLTIMAS INCIDENCIAS
$incidencias = [];

$sqlUltimas = "
    SELECT
        c.ID_Control,
        c.Fecha,
        e.Nombre_Estudiante,
        s.Nombre_Seccion,
        GROUP_CONCAT(
            DISTINCT f.NomF
            ORDER BY f.NomF
            SEPARATOR ', '
        ) AS faltas
    FROM `Control` c

    INNER JOIN `Estudiante` e
        ON e.NIE = c.NIE

    LEFT JOIN `Seccion` s
        ON s.ID_Seccion = e.ID_Seccion

    LEFT JOIN `Control_Falta` cf
        ON cf.ID_Control = c.ID_Control

    LEFT JOIN `Faltas` f
        ON f.CodF = cf.CodF

    GROUP BY
        c.ID_Control,
        c.Fecha,
        e.Nombre_Estudiante,
        s.Nombre_Seccion

    ORDER BY c.Fecha DESC, c.ID_Control DESC
    LIMIT 5
";

$resultadoUltimas = mysqli_query($conexion, $sqlUltimas);

if ($resultadoUltimas) {
    while ($fila = mysqli_fetch_assoc($resultadoUltimas)) {

        $nombre = (string)$fila['Nombre_Estudiante'];

        $partes = preg_split(
            '/\s+/',
            trim($nombre),
            -1,
            PREG_SPLIT_NO_EMPTY
        );

        $iniciales = '';

        foreach (array_slice($partes, 0, 2) as $parte) {
            $letra = function_exists('mb_substr')
                ? mb_substr($parte, 0, 1, 'UTF-8')
                : substr($parte, 0, 1);

            $iniciales .= function_exists('mb_strtoupper')
                ? mb_strtoupper($letra, 'UTF-8')
                : strtoupper($letra);
        }

        if ($iniciales === '') {
            $iniciales = 'E';
        }

        $incidencias[] = [
            'iniciales' => $iniciales,
            'nombre' => $nombre,
            'detalle' => ($fila['faltas'] ?: 'Incidencia registrada')
                . ' · '
                . ($fila['Nombre_Seccion'] ?: 'Sin sección'),
            'fecha' => date('d/m/Y', strtotime($fila['Fecha']))
        ];
    }
}

// Abrir la plantilla general
inac_inicio_pagina('Inicio', 'inicio');
?>

<style>
/* DISEÑO DEL PANEL DE INICIO */
.inicio-panel {
    --inicio-line: #dce5f1;
    --inicio-muted: #64748b;
    --inicio-blue: #1e3a8a;
    font-family: 'Segoe UI', Arial, sans-serif;
    color: #0f172a;
    font-size: 13px;
}

.inicio-panel * {
    box-sizing: border-box;
}

.inicio-panel a {
    text-decoration: none;
}

.inicio-panel .section-heading {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
    margin-bottom: 25px;
}

.inicio-panel .section-heading h1 {
    font-size: 24px;
    margin: 0 0 8px;
    color: #0f172a;
}

.inicio-panel .section-heading p {
    margin: 0;
    color: #647a9c;
    font-size: 13px;
}

.inicio-panel .primary-btn {
    display: inline-block;
    background: #1e4295;
    color: #fff;
    padding: 14px 20px;
    border-radius: 7px;
    font-size: 12px;
    font-weight: 600;
    white-space: nowrap;
}

.inicio-panel .primary-btn:hover {
    background: #2563eb;
}

.inicio-panel .stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 16px;
}

.inicio-panel .stat,
.inicio-panel .panel {
    background: #fff;
    border: 1px solid #dce5f1;
    border-radius: 13px;
    box-shadow: 0 4px 20px rgba(20, 46, 88, .04);
}

.inicio-panel .stat {
    min-height: 156px;
    padding: 20px 19px;
}

.inicio-panel .stat-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 7px;
    color: #637a9e;
    font-size: 12px;
}

.inicio-panel .stat-icon {
    height: 37px;
    width: 37px;
    display: grid;
    place-items: center;
    border-radius: 10px;
    font-size: 19px;
    flex-shrink: 0;
}

.inicio-panel .azul {
    background: #dceafe;
    color: #1d4ed8;
}

.inicio-panel .amarillo {
    background: #fff2c9;
    color: #ca8a04;
}

.inicio-panel .rojo {
    background: #fee2e2;
    color: #dc2626;
}

.inicio-panel .stat-value {
    font-size: 29px;
    font-weight: 750;
    margin: 19px 0 9px;
    color: #0f172a;
}

.inicio-panel .stat-detail {
    color: #00984b;
    font-size: 11px;
}

.inicio-panel .lower {
    display: grid;
    grid-template-columns: 1.4fr 1fr;
    gap: 18px;
    margin-top: 19px;
}

.inicio-panel .panel {
    padding: 21px 22px;
    min-width: 0;
}

.inicio-panel .panel-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin-bottom: 22px;
}

.inicio-panel .panel-head h2 {
    font-size: 16px;
    margin: 0;
}

.inicio-panel .panel-head span {
    color: #7187a9;
}

.inicio-panel .outline-btn {
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 8px 12px;
    background: #fff;
    color: #0f172a;
    font-size: 11px;
}

.inicio-panel .chart {
    height: 226px;
    display: flex;
    position: relative;
    padding: 0 0 25px 32px;
}

.inicio-panel .y-labels {
    position: absolute;
    top: 0;
    bottom: 25px;
    left: 0;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    color: #7489aa;
    font-size: 10px;
}

.inicio-panel .plot {
    flex: 1;
    position: relative;
    border-left: 1px solid #d6e1ef;
    border-bottom: 1px solid #d6e1ef;
    background: repeating-linear-gradient(
        to top,
        transparent 0,
        transparent calc(25% - 1px),
        #e8eef6 calc(25% - 1px),
        #e8eef6 25%
    );
}

.inicio-panel .bars {
    position: absolute;
    inset: 0;
    display: flex;
    justify-content: space-around;
    align-items: flex-end;
    gap: 12px;
    padding: 0 12px;
}

.inicio-panel .bar-slot {
    height: 100%;
    flex: 1;
    display: flex;
    justify-content: flex-end;
    align-items: center;
    flex-direction: column;
    position: relative;
}

.inicio-panel .bar {
    width: 65%;
    max-width: 55px;
    border-radius: 5px 5px 0 0;
    background: linear-gradient(#5a9cfc, #2465e9);
}

.inicio-panel .month {
    position: absolute;
    top: calc(100% + 9px);
    font-size: 11px;
    color: #637a9e;
}

.inicio-panel .incident {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 13px 0;
    border-bottom: 1px solid #e8eef5;
}

.inicio-panel .incident:last-child {
    border: 0;
}

.inicio-panel .initials {
    height: 42px;
    width: 42px;
    flex-shrink: 0;
    border-radius: 12px;
    background: #eaf2ff;
    display: grid;
    place-items: center;
    color: #1d4ed8;
    font-weight: 700;
    font-size: 15px;
}

.inicio-panel .incident-info {
    flex: 1;
    min-width: 0;
}

.inicio-panel .incident-info strong {
    display: block;
    font-size: 12px;
}

.inicio-panel .incident-info small {
    display: block;
    color: #7187a9;
    font-size: 11px;
    margin-top: 7px;
}

.inicio-panel .incident time {
    font-size: 11px;
    color: #7287a8;
    white-space: nowrap;
}

.inicio-panel .search-result {
    margin-top: 12px;
    color: #64748b;
    font-size: 11px;
    display: none;
}

@media (max-width: 1200px) {
    .inicio-panel .stats {
        grid-template-columns: repeat(2, 1fr);
    }

    .inicio-panel .lower {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 600px) {
    .inicio-panel .section-heading {
        flex-wrap: wrap;
    }

    .inicio-panel .stats {
        gap: 10px;
    }

    .inicio-panel .stat {
        padding: 14px;
        min-height: 145px;
    }

    .inicio-panel .panel {
        padding: 16px;
    }
}

@media (max-width: 430px) {
    .inicio-panel .stats {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="inicio-panel">

    <!-- RESUMEN GENERAL -->
    <div class="section-heading">

        <div>
            <h1>Resumen general</h1>
            <p>Bienvenido al sistema de control de faltas escolares.</p>
        </div>

        <a class="primary-btn" href="registrar_falta.php">
            ▤ Consultar faltas
        </a>

    </div>

    <!-- TARJETAS ESTADÍSTICAS -->
    <section class="stats" aria-label="Estadísticas generales">

        <?php foreach ($estadisticas as $dato): ?>

            <article class="stat">

                <div class="stat-head">
                    <span><?= h_inicio($dato['titulo']) ?></span>

                    <span class="stat-icon <?= h_inicio($dato['clase']) ?>">
                        <?= h_inicio($dato['icono']) ?>
                    </span>
                </div>

                <div class="stat-value">
                    <?= number_format($dato['valor'], 0, '.', ',') ?>
                </div>

                <div class="stat-detail">
                    <?= h_inicio($dato['detalle']) ?>
                </div>

            </article>

        <?php endforeach; ?>

    </section>

    <!-- GRÁFICO Y ÚLTIMAS INCIDENCIAS -->
    <div class="lower">

        <section class="panel">

            <div class="panel-head">
                <h2>Faltas registradas por mes</h2>
                <span>Últimos 7 meses</span>
            </div>

            <div class="chart" role="img"
                 aria-label="Gráfico de faltas registradas por mes">

                <div class="y-labels">
                    <span><?= $maxGrafico ?></span>
                    <span><?= (int)($maxGrafico * .75) ?></span>
                    <span><?= (int)($maxGrafico * .5) ?></span>
                    <span><?= (int)($maxGrafico * .25) ?></span>
                    <span>0</span>
                </div>

                <div class="plot">
                    <div class="bars">

                        <?php foreach ($meses as $i => $mes): ?>

                            <div class="bar-slot">

                                <div
                                    class="bar"
                                    style="height: <?= (int)(
                                        $valores[$i] / $maxGrafico * 100
                                    ) ?>%"
                                    title="<?= h_inicio($mes) ?>: <?= (int)$valores[$i] ?> faltas"
                                ></div>

                                <span class="month">
                                    <?= h_inicio($mes) ?>
                                </span>

                            </div>

                        <?php endforeach; ?>

                    </div>
                </div>

            </div>

        </section>

        <!-- ÚLTIMAS INCIDENCIAS -->
        <section class="panel">

            <div class="panel-head">
                <h2>Últimas incidencias</h2>

                <a class="outline-btn" href="reportes.php">
                    Ver todas
                </a>
            </div>

            <div id="lista-incidencias">

                <?php foreach ($incidencias as $inc): ?>

                    <div
                        class="incident"
                        data-nombre="<?= h_inicio(
                            strtolower($inc['nombre'])
                        ) ?>"
                    >

                        <div class="initials">
                            <?= h_inicio($inc['iniciales']) ?>
                        </div>

                        <div class="incident-info">

                            <strong>
                                <?= h_inicio($inc['nombre']) ?>
                            </strong>

                            <small>
                                <?= h_inicio($inc['detalle']) ?>
                            </small>

                        </div>

                        <time>
                            <?= h_inicio($inc['fecha']) ?>
                        </time>

                    </div>

                <?php endforeach; ?>

                <?php if (!$incidencias): ?>
                    <p>No hay incidencias registradas.</p>
                <?php endif; ?>

            </div>

            <div id="sin-resultados" class="search-result">
                No hay coincidencias en las incidencias mostradas.
            </div>

        </section>

    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {

    const buscar = document.getElementById('busqueda');

    if (!buscar) {
        return;
    }

    buscar.addEventListener('input', function() {

        const texto = this.value.toLocaleLowerCase('es').trim();
        let visibles = 0;

        document.querySelectorAll('.inicio-panel .incident')
            .forEach(function(fila) {

                const nombre = fila.dataset.nombre || '';
                const coincide = nombre.includes(texto);

                fila.style.display = coincide ? 'flex' : 'none';

                if (coincide) {
                    visibles++;
                }
            });

        const sinResultados = document.getElementById('sin-resultados');

        if (sinResultados) {
            sinResultados.style.display =
                visibles || texto === '' ? 'none' : 'block';
        }
    });

});
</script>

<?php
// Cerrar la plantilla compartida
inac_fin_pagina();
?>
