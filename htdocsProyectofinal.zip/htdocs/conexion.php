<?php
// Conexión a la base de datos MySQL

$host ="sql102.infinityfree.com"; 
$usuario ="if0_43155583"; 
$contrasena ="lYidQmyblQDLExM"; 
$base_de_datos = "if0_43155583_Proyectoconivett";

$conexion = mysqli_connect($host, $usuario, $contrasena, $base_de_datos);

// Verificar conexión
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}
//echo "Conexión exitosa";
?>
