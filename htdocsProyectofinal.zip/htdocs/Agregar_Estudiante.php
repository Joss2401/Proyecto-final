<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['id_usuario'])) {
    header('Location: Faltas_Login.php');
    exit;
}
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/plantilla_inac.php';

if (!isset($conexion) || !($conexion instanceof mysqli) || $conexion->connect_error) {
    die('No se pudo conectar a MySQL.');
}
$conexion->set_charset('utf8mb4');

function est_h($texto) { return htmlspecialchars((string)$texto, ENT_QUOTES, 'UTF-8'); }
$mensaje = '';
$exito = false;
$nie = trim((string)($_POST['nie'] ?? ''));
$nombre = trim((string)($_POST['nombre_estudiante'] ?? ''));
$idSeccion = trim((string)($_POST['id_seccion'] ?? ''));
$secciones = [];

$consulta = $conexion->query('SELECT ID_Seccion, Nombre_Seccion FROM Seccion ORDER BY Nombre_Seccion');
if ($consulta) {
    while ($fila = $consulta->fetch_assoc()) $secciones[] = $fila;
    $consulta->free();
} else {
    $mensaje = 'No se pudieron cargar las secciones. Revise la tabla Seccion.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $mensaje === '') {
    if ($nie === '' || $nombre === '' || $idSeccion === '') {
        $mensaje = 'Complete el NIE, el nombre y la sección.';
    } elseif (strlen($nie) > 30 || mb_strlen($nombre) > 200) {
        $mensaje = 'Revise la longitud del NIE o del nombre.';
    } else {
        $seccionValida = false;
        foreach ($secciones as $s) {
            if ((string)$s['ID_Seccion'] === $idSeccion) { $seccionValida = true; break; }
        }
        if (!$seccionValida) {
            $mensaje = 'Seleccione una sección válida.';
        } else {
            $verificar = $conexion->prepare('SELECT NIE FROM Estudiante WHERE NIE = ? LIMIT 1');
            if (!$verificar) {
                $mensaje = 'No se pudo verificar el NIE.';
            } else {
                $verificar->bind_param('s', $nie);
                $verificar->execute();
                $verificar->store_result();
                $existe = $verificar->num_rows > 0;
                $verificar->close();
                if ($existe) {
                    $mensaje = 'Ya existe un estudiante registrado con ese NIE.';
                } else {
                    $guardar = $conexion->prepare('INSERT INTO Estudiante (NIE, Nombre_Estudiante, ID_Seccion) VALUES (?, ?, ?)');
                    if (!$guardar) {
                        $mensaje = 'No se pudo preparar el registro: ' . $conexion->error;
                    } else {
                        $guardar->bind_param('sss', $nie, $nombre, $idSeccion);
                        if ($guardar->execute()) {
                            $exito = true;
                            $mensaje = '¡Estudiante registrado correctamente!';
                            $nie = $nombre = $idSeccion = '';
                        } else {
                            $mensaje = 'No se pudo guardar el estudiante: ' . $guardar->error;
                        }
                        $guardar->close();
                    }
                }
            }
        }
    }
}

inac_inicio_pagina('Agregar estudiante', 'estudiantes');
?>
<style>
.est-contenedor{max-width:1000px;margin:0 auto;padding:4px 0 30px}
.est-intro{color:#64748b;font-size:14px;margin:0 0 22px}
.est-panel{background:#fff;border:1px solid #dce5f0;border-radius:12px;overflow:hidden;box-shadow:0 3px 14px #172c4a08}
.est-panel-titulo{display:flex;align-items:center;gap:12px;padding:18px 22px;border-bottom:1px solid #edf1f6}
.est-letra{background:#e8efff;color:#1e3a8a;font-weight:700;padding:10px 13px;border-radius:8px}
.est-panel-titulo h2{font-size:17px;margin:0;color:#0f172a}
.est-campos{display:grid;grid-template-columns:1fr 1fr;gap:20px;padding:24px}
.est-campo{display:flex;flex-direction:column;gap:8px}
.est-campo.est-ancho{grid-column:1/-1}
.est-campo label{font-size:13px;font-weight:700;color:#0f172a}
.est-campo input,.est-campo select{width:100%;padding:12px;border:1px solid #cbd5e1;border-radius:7px;background:#fff;color:#0f172a;font:inherit}
.est-campo input:focus,.est-campo select:focus{outline:2px solid #bfdbfe;border-color:#2563eb}
.est-ayuda{font-size:12px;color:#64748b}
.est-acciones{display:flex;justify-content:flex-end;gap:12px;padding:0 24px 24px}
.est-boton{display:inline-block;text-decoration:none;border:1px solid #cbd5e1;border-radius:8px;padding:12px 20px;background:#fff;color:#334155;font-weight:700;cursor:pointer;font-size:14px}
.est-boton.est-primario{background:#1e3a8a;border-color:#1e3a8a;color:#fff}
.est-boton.est-primario:hover{background:#2563eb}
.est-aviso{padding:14px 16px;border-radius:8px;margin-bottom:18px;font-size:14px}
.est-aviso.ok{background:#f0fdf4;color:#166534;border:1px solid #bbf7d0}
.est-aviso.error{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}
@media(max-width:700px){.est-campos{grid-template-columns:1fr}.est-campo.est-ancho{grid-column:auto}.est-acciones{flex-wrap:wrap}}
</style>
<div class="est-contenedor">
    <h1 style="margin:0 0 8px;font-size:24px;color:#0f172a">Registro de estudiantes</h1>
    <p class="est-intro">Complete los datos para incorporar un estudiante al sistema de control de faltas.</p>
    <?php if ($mensaje !== ''): ?>
        <div class="est-aviso <?= $exito ? 'ok' : 'error' ?>" role="alert"><?= est_h($mensaje) ?></div>
    <?php endif; ?>
    <form method="post" action="Agregar_Estudiante.php" class="est-panel">
        <div class="est-panel-titulo"><span class="est-letra">A</span><h2>Datos del estudiante</h2></div>
        <div class="est-campos">
            <div class="est-campo est-ancho">
                <label for="nie">NIE del estudiante *</label>
                <input type="text" id="nie" name="nie" value="<?= est_h($nie) ?>" placeholder="Ingrese el NIE" maxlength="30" required autocomplete="off">
                <span class="est-ayuda">El NIE debe ser único para cada estudiante.</span>
            </div>
            <div class="est-campo">
                <label for="nombre_estudiante">Nombre completo del estudiante *</label>
                <input type="text" id="nombre_estudiante" name="nombre_estudiante" value="<?= est_h($nombre) ?>" placeholder="Nombre y apellidos" maxlength="200" required>
            </div>
            <div class="est-campo">
                <label for="id_seccion">Sección *</label>
                <select id="id_seccion" name="id_seccion" required>
                    <option value="">-- Seleccione una sección --</option>
                    <?php foreach ($secciones as $seccion): ?>
                        <option value="<?= est_h($seccion['ID_Seccion']) ?>" <?= (string)$seccion['ID_Seccion'] === $idSeccion ? 'selected' : '' ?>><?= est_h($seccion['Nombre_Seccion']) ?></option>
                    <?php endforeach; ?>
                </select>
                <span class="est-ayuda">Las secciones se cargan desde tu base de datos.</span>
            </div>
        </div>
        <div class="est-acciones">
            <a href="Faltas_Inicio.php" class="est-boton">Cancelar</a>
            <button type="submit" class="est-boton est-primario">Guardar estudiante</button>
        </div>
    </form>
</div>
<?php inac_fin_pagina(); ?>
