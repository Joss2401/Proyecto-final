<?php
// Mostrar errores solo durante el desarrollo
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);
mysqli_report(MYSQLI_REPORT_OFF);
session_start();
if (!isset($_SESSION['id_usuario'])) {
    header('Location: Faltas_Login.php');
    exit;
}
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/plantilla_inac.php';

$mensaje = '';
$tipo_alerta = '';
$datos = $_POST;
$estudiantes = [];
$docentes = [];
$faltas_disponibles = [];

// Mostrar la confirmación una sola vez después de redirigir (POST -> GET).
if (isset($_SESSION['inac_registro_exito'])) {
    $mensaje = (string)$_SESSION['inac_registro_exito'];
    $tipo_alerta = 'alert-success';
    unset($_SESSION['inac_registro_exito']);
}

function escapar($valor) {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}
function anterior($campo, $valor = '') {
    global $datos;
    return escapar(isset($datos[$campo]) ? $datos[$campo] : $valor);
}

if (!isset($conexion) || !($conexion instanceof mysqli) || $conexion->connect_error) {
    die('No se pudo establecer la conexión con MySQL.');
}
$conexion->set_charset('utf8mb4');

// Consultar estudiantes y su sección
$sql = "SELECT E.NIE, E.Nombre_Estudiante, S.Nombre_Seccion
        FROM Estudiante E
        LEFT JOIN Seccion S ON E.ID_Seccion = S.ID_Seccion
        ORDER BY E.Nombre_Estudiante";
$resultado = $conexion->query($sql);
if ($resultado) {
    while ($fila = $resultado->fetch_assoc()) { $estudiantes[] = $fila; }
    $resultado->free();
} else {
    error_log('Error al consultar estudiantes: ' . $conexion->error);
    $mensaje = 'No se pudieron cargar los datos de estudiantes.';
    $tipo_alerta = 'alert-error';
}

// Consultar docentes
$sql = "SELECT DUI, NombreCompleD FROM Docente ORDER BY NombreCompleD";
$resultado = $conexion->query($sql);
if ($resultado) {
    while ($fila = $resultado->fetch_assoc()) { $docentes[] = $fila; }
    $resultado->free();
} else {
    error_log('Error al consultar docentes: ' . $conexion->error);
    $mensaje = 'No se pudieron cargar los datos de docentes.';
    $tipo_alerta = 'alert-error';
}

// Consultar faltas
$sql = "SELECT CodF, NomF FROM Faltas ORDER BY CodF";
$resultado = $conexion->query($sql);
if ($resultado) {
    while ($fila = $resultado->fetch_assoc()) { $faltas_disponibles[] = $fila; }
    $resultado->free();
} else {
    error_log('Error al consultar faltas: ' . $conexion->error);
    $mensaje = 'No se pudieron cargar los datos de faltas.';
    $tipo_alerta = 'alert-error';
}

// Guardar datos del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $NIE = isset($_POST['nie']) ? trim($_POST['nie']) : '';
    $DUI = isset($_POST['dui_docente']) ? trim($_POST['dui_docente']) : '';
    $Fecha = isset($_POST['fecha']) ? trim($_POST['fecha']) : '';
    $Observacion = isset($_POST['observaciones']) ? trim($_POST['observaciones']) : '';
    $Compromiso_Estudiante = isset($_POST['compromiso_estudiante']) ? trim($_POST['compromiso_estudiante']) : '';
    $Compromiso_PadreFamilia = isset($_POST['compromiso_familia']) ? trim($_POST['compromiso_familia']) : '';
    $Faltas = isset($_POST['faltas']) && is_array($_POST['faltas']) ? $_POST['faltas'] : [];
    $Trabajo = isset($_POST['trabajo']) ? trim($_POST['trabajo']) : '';
    $Horas = isset($_POST['tiempo']) ? trim($_POST['tiempo']) : '';
    $Fecha_Asignacion = isset($_POST['fecha_limite']) ? trim($_POST['fecha_limite']) : '';
    $fecha_valida = DateTime::createFromFormat('!Y-m-d', $Fecha);
    $fecha_trabajo_valida = $Fecha_Asignacion !== '' ? DateTime::createFromFormat('!Y-m-d', $Fecha_Asignacion) : false;

    if ($NIE === '' || $DUI === '' || $Fecha === '' || count($Faltas) === 0) {
        $mensaje = 'Seleccione estudiante, docente, fecha y al menos una falta.';
        $tipo_alerta = 'alert-error';
    } elseif (!$fecha_valida || $fecha_valida->format('Y-m-d') !== $Fecha) {
        $mensaje = 'La fecha del incidente no es válida.';
        $tipo_alerta = 'alert-error';
    } elseif (mb_strlen($Observacion) > 200 || mb_strlen($Compromiso_Estudiante) > 200 || mb_strlen($Compromiso_PadreFamilia) > 200) {
        $mensaje = 'Observaciones y compromisos: máximo 200 caracteres por campo.';
        $tipo_alerta = 'alert-error';
    } elseif (($Trabajo !== '' || $Horas !== '' || $Fecha_Asignacion !== '') && ($Trabajo === '' || $Horas === '' || $Fecha_Asignacion === '')) {
        $mensaje = 'Para asignar trabajo comunitario, complete descripción, horas y fecha.';
        $tipo_alerta = 'alert-error';
    } elseif ($Trabajo !== '' && (mb_strlen($Trabajo) > 200 || !ctype_digit($Horas) || (int)$Horas < 1 || (int)$Horas > 838 || !$fecha_trabajo_valida || $fecha_trabajo_valida->format('Y-m-d') !== $Fecha_Asignacion)) {
        $mensaje = 'Revise las horas de trabajo (1 a 838), descripción y fecha.';
        $tipo_alerta = 'alert-error';
    } else {
        // Comprobar que los valores seleccionados existen en MySQL
        $estudiante_existe = false;
        foreach ($estudiantes as $fila) {
            if ((string)$fila['NIE'] === $NIE) { $estudiante_existe = true; }
        }
        $docente_existe = false;
        foreach ($docentes as $fila) {
            if ((string)$fila['DUI'] === $DUI) { $docente_existe = true; }
        }
        $codigos_disponibles = [];
        foreach ($faltas_disponibles as $fila) {
            $codigos_disponibles[] = (string)$fila['CodF'];
        }
        $Faltas = array_values(array_unique(array_map('strval', $Faltas)));
        $codigos_correctos = true;
        foreach ($Faltas as $codigo) {
            if (!in_array($codigo, $codigos_disponibles, true)) {
                $codigos_correctos = false;
            }
        }

        if (!$estudiante_existe || !$docente_existe || !$codigos_correctos) {
            $mensaje = 'El estudiante, docente o alguna falta no existe en la base de datos.';
            $tipo_alerta = 'alert-error';
        } else {
            // Guardar las tres tablas como una sola operación
            $transaccion_iniciada = $conexion->begin_transaction();
            $guardado = $transaccion_iniciada;
            $error_guardado = $transaccion_iniciada ? '' : $conexion->error;

            $sql_insert = "INSERT INTO Control (Fecha, `Observación`, Compromiso_Estudiante, Compromiso_PadreFamilia, NIE, DUI) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $guardado ? $conexion->prepare($sql_insert) : false;
            if (!$stmt) {
                $guardado = false;
                $error_guardado = $conexion->error;
            } else {
                $stmt->bind_param('ssssss', $Fecha, $Observacion, $Compromiso_Estudiante, $Compromiso_PadreFamilia, $NIE, $DUI);
                if (!$stmt->execute()) {
                    $guardado = false;
                    $error_guardado = $stmt->error;
                }
                $stmt->close();
            }

            if ($guardado) {
                $ID_Control = $conexion->insert_id;
                if ($ID_Control <= 0) {
                    $guardado = false;
                    $error_guardado = 'ID_Control no se generó. Compruebe AUTO_INCREMENT.';
                }
            }

            if ($guardado) {
                $sql_insert = "INSERT INTO Control_Falta (ID_Control, CodF) VALUES (?, ?)";
                $stmt = $conexion->prepare($sql_insert);
                if (!$stmt) {
                    $guardado = false;
                    $error_guardado = $conexion->error;
                } else {
                    foreach ($Faltas as $codigo) {
                        $CodF = (int)$codigo;
                        $stmt->bind_param('ii', $ID_Control, $CodF);
                        if (!$stmt->execute()) {
                            $guardado = false;
                            $error_guardado = $stmt->error;
                            break;
                        }
                    }
                    $stmt->close();
                }
            }

            if ($guardado && $Trabajo !== '') {
                $Tiempo = sprintf('%02d:00:00', (int)$Horas);
                // La tabla puede llamarse Asignación (con tilde), como en el diagrama.
                // Detectamos el nombre real sin modificar la base de datos.
                $nombre_asignacion = null;
                $tablas = $conexion->query('SHOW TABLES');
                if ($tablas) {
                    while ($tabla = $tablas->fetch_row()) {
                        if ($tabla[0] === 'Asignación' || $tabla[0] === 'Asignacion') {
                            $nombre_asignacion = $tabla[0];
                            if ($nombre_asignacion === 'Asignación') break;
                        }
                    }
                    $tablas->free();
                }
                if ($nombre_asignacion === null) {
                    $guardado = false;
                    $error_guardado = 'No existe la tabla Asignación/Asignacion en esta base de datos.';
                }
                $tabla_segura = $nombre_asignacion !== null ? '`' . $nombre_asignacion . '`' : '';
                $sql_insert = "INSERT INTO $tabla_segura (Descripcion, Tiempo, Fecha, ID_Control) VALUES (?, ?, ?, ?)";
                $stmt = $guardado ? $conexion->prepare($sql_insert) : false;
                if (!$stmt) {
                    $guardado = false;
                    if ($error_guardado === '') $error_guardado = $conexion->error;
                } else {
                    $stmt->bind_param('sssi', $Trabajo, $Tiempo, $Fecha_Asignacion, $ID_Control);
                    if (!$stmt->execute()) {
                        $guardado = false;
                        $error_guardado = $stmt->error;
                    }
                    $stmt->close();
                }
            }

            if ($guardado) {
                if ($conexion->commit()) {
                    // El registro ya se guardó: no volver a procesar el POST al actualizar.
                    $_SESSION['inac_registro_exito'] = '¡Falta registrada exitosamente! Número de control: ' . $ID_Control;
                    header('Location: Registro_Faltas_INAC.php', true, 303);
                    exit;
                } else {
                    if ($transaccion_iniciada) $conexion->rollback();
                    error_log('Error al confirmar registro INAC: ' . $conexion->error);
                    $mensaje = 'No se pudo confirmar el registro. Intente nuevamente o contacte al encargado.';
                    $tipo_alerta = 'alert-error';
                }
            } else {
                if ($transaccion_iniciada) $conexion->rollback();
                error_log('Error al guardar falta INAC: ' . $error_guardado);
                $mensaje = 'No se pudo guardar la falta. Revise los datos o solicite al encargado revisar el registro de errores del servidor.';
                $tipo_alerta = 'alert-error';
            }
        }
    }
}
?>
<?php inac_inicio_pagina('Registrar faltas', 'registrar'); ?>
<link rel="stylesheet" href="registro_faltas_estilos.css?v=2">

<div class="inac-registro">
<p class="intro">Complete los datos del reporte de incidencias estudiantiles.</p>
<?php if ($mensaje !== '') { ?>
<div class="alert <?php echo escapar($tipo_alerta); ?>"><?php echo escapar($mensaje); ?></div>
<?php } ?>
<form action="Registro_Faltas_INAC.php" method="POST">
<section class="panel"><div class="panelhead"><span class="letter">A</span><h2>Datos del estudiante y reportante</h2></div>
<div class="panelbody fields">
<div class="field span2">
<label for="buscar_nie">Buscar estudiante por NIE *</label>
<input type="text" id="buscar_nie" placeholder="Escriba el NIE del estudiante" autocomplete="off" inputmode="numeric">
<select id="nie" name="nie" required style="margin-top:9px">
<option value="">-- Seleccione el NIE del estudiante --</option>
<?php foreach ($estudiantes as $fila) { ?>
<option value="<?php echo escapar($fila['NIE']); ?>"
        data-nombre="<?php echo escapar($fila['Nombre_Estudiante']); ?>"
        data-seccion="<?php echo escapar($fila['Nombre_Seccion'] ?? ''); ?>"
        <?php if (isset($datos['nie']) && (string)$datos['nie'] === (string)$fila['NIE']) { echo 'selected'; } ?>>
    <?php echo escapar($fila['NIE']); ?>
</option>
<?php } ?>
</select>
<div class="help">Escriba el NIE y selecciónelo en la lista filtrada.</div>
</div>
<div class="field">
<label for="nombre_estudiante">Nombre del estudiante</label>
<input type="text" id="nombre_estudiante" readonly placeholder="Se completa automáticamente">
</div>
<div class="field">
<label for="seccion">Sección</label>
<input type="text" id="seccion" readonly placeholder="Se completa automáticamente">
</div>
<div class="field">
<label for="dui_docente">Docente que reporta *</label>
<select id="dui_docente" name="dui_docente" required>
<option value="">-- Seleccione docente --</option>
<?php foreach ($docentes as $fila) { ?>
<option value="<?php echo escapar($fila['DUI']); ?>" <?php if (isset($datos['dui_docente']) && (string)$datos['dui_docente'] === (string)$fila['DUI']) { echo 'selected'; } ?>><?php echo escapar($fila['NombreCompleD'] . ' - ' . $fila['DUI']); ?></option>
<?php } ?>
</select>
</div>
<div class="field">
<label for="fecha">Fecha del incidente *</label>
<input type="date" id="fecha" name="fecha" value="<?php echo anterior('fecha', date('Y-m-d')); ?>" required>
</div>
</div></section>
<section class="panel"><div class="panelhead"><span class="letter">B</span><h2>Tipos de faltas cometidas</h2></div><div class="panelbody"><div class="checks">
<?php foreach ($faltas_disponibles as $fila) { ?>
<label class="check"><input type="checkbox" name="faltas[]" value="<?php echo escapar($fila['CodF']); ?>" <?php if (isset($datos['faltas']) && is_array($datos['faltas']) && in_array((string)$fila['CodF'], array_map('strval', $datos['faltas']), true)) { echo 'checked'; } ?>>
<span><?php echo escapar($fila['CodF'] . '. ' . $fila['NomF']); ?></span></label>
<?php } ?>
</div></div></section>
<section class="panel"><div class="panelhead"><span class="letter">C</span><h2>Detalle y compromisos</h2></div><div class="panelbody fields">
<div class="field span2"><label for="observaciones">Observaciones</label><textarea id="observaciones" name="observaciones" maxlength="200" placeholder="Describa lo ocurrido..."><?php echo anterior('observaciones'); ?></textarea></div>
<div class="field"><label for="compromiso_estudiante">Compromiso del estudiante</label><textarea id="compromiso_estudiante" name="compromiso_estudiante" maxlength="200"><?php echo anterior('compromiso_estudiante'); ?></textarea></div>
<div class="field"><label for="compromiso_familia">Compromiso del padre o representante</label><textarea id="compromiso_familia" name="compromiso_familia" maxlength="200"><?php echo anterior('compromiso_familia'); ?></textarea></div>
</div></section>
<section class="panel"><div class="panelhead"><span class="letter">D</span><h2>Trabajo comunitario / medida correctiva</h2></div><div class="panelbody fields">
<div class="field span2"><label for="trabajo">Descripción del trabajo comunitario</label><textarea id="trabajo" name="trabajo" maxlength="200" placeholder="Complete solo cuando corresponda..."><?php echo anterior('trabajo'); ?></textarea></div>
<div class="field"><label for="tiempo">Tiempo de cumplimiento (horas)</label><input type="number" min="1" max="838" step="1" id="tiempo" name="tiempo" value="<?php echo anterior('tiempo'); ?>" placeholder="Ej. 3"><div class="help">Indique únicamente la cantidad de horas.</div></div>
<div class="field"><label for="fecha_limite">Fecha de cumplimiento</label><input type="date" id="fecha_limite" name="fecha_limite" value="<?php echo anterior('fecha_limite'); ?>"></div>
</div></section>
<div class="actions"><a href="Faltas_Inicio.php" class="btn">Cancelar</a><button type="submit" class="btn primary">Guardar falta</button></div>
</form>

</div>
<script>
const buscarNIE = document.getElementById('buscar_nie');
const listaNIE = document.getElementById('nie');
const nombreEstudiante = document.getElementById('nombre_estudiante');
const seccionEstudiante = document.getElementById('seccion');
const opcionesOriginales = Array.from(listaNIE.options).slice(1).map(op => op.cloneNode(true));

function actualizarEstudiante() {
    const opcion = listaNIE.selectedOptions[0];
    nombreEstudiante.value = opcion ? (opcion.dataset.nombre || '') : '';
    seccionEstudiante.value = opcion ? (opcion.dataset.seccion || '') : '';
}

buscarNIE.addEventListener('input', function () {
    const filtro = this.value.trim().toLowerCase();
    const seleccionado = listaNIE.value;
    listaNIE.replaceChildren(new Option('-- Seleccione el NIE del estudiante --', ''));
    opcionesOriginales.forEach(function (opcion) {
        if (opcion.value.toLowerCase().includes(filtro)) {
            listaNIE.appendChild(opcion.cloneNode(true));
        }
    });
    if (Array.from(listaNIE.options).some(op => op.value === seleccionado)) {
        listaNIE.value = seleccionado;
    } else {
        listaNIE.value = '';
    }
    actualizarEstudiante();
});

listaNIE.addEventListener('change', function () {
    if (this.value) buscarNIE.value = this.value;
    actualizarEstudiante();
});

if (listaNIE.value) buscarNIE.value = listaNIE.value;
actualizarEstudiante();
</script>
<?php inac_fin_pagina(); ?>
