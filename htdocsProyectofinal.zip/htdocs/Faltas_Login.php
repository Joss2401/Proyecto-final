
<?php
session_start();

// Si ya inició sesión, enviar al inicio
if (isset($_SESSION['id_usuario'])) {
    header("Location: Faltas_Inicio.php");
    exit;
}

// Conexión a la base de datos
require_once __DIR__ . '/conexion.php';

$mensaje = '';

// ÚNICAMENTE DOS ROLES PERMITIDOS
$roles = [
    'administrador' => 'Administrador',
    'docente' => 'Docente Guía / Reportante'
];

// Procesar inicio de sesión
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $rol = $_POST['rol'] ?? '';
    $clave = $_POST['clave'] ?? '';

    if (!array_key_exists($rol, $roles) || $clave === '') {

        $mensaje = 'Seleccione un rol e ingrese su contraseña.';

    } elseif (
        !isset($conexion) ||
        !($conexion instanceof mysqli) ||
        $conexion->connect_error
    ) {

        $mensaje = 'No se pudo conectar con la base de datos.';

    } else {

        $stmt = $conexion->prepare(
            "SELECT id_usuario, contrasena
             FROM usuarios
             WHERE rol = ?
             AND estado = 'activo'
             LIMIT 1"
        );

        if (!$stmt) {

            $mensaje = 'No se pudo consultar la cuenta.';

        } else {

            $stmt->bind_param('s', $rol);
            $stmt->execute();
            $stmt->bind_result($id, $hash);

            $valido = $stmt->fetch()
                && password_verify($clave, $hash);

            $stmt->close();

            if ($valido) {

                session_regenerate_id(true);

                $_SESSION['id_usuario'] = $id;
                $_SESSION['rol'] = $rol;
                $_SESSION['nombre_rol'] = $roles[$rol];

                header('Location: Faltas_Inicio.php');
                exit;
            }

            $mensaje = 'Rol o contraseña incorrectos.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Inicio de sesión | INAC</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: 'Segoe UI', Arial, sans-serif;
    color: #0f172a;
}

.contenedor {
    min-height: 100vh;
    display: flex;
}

.izquierda {
    width: 51.2%;
    background: linear-gradient(135deg, #111e3d, #1e3a8a);
    color: #fff;
    padding: 70px 7%;
    display: flex;
    align-items: center;
    position: relative;
    overflow: hidden;
}

.izquierda:after {
    content: "";
    position: absolute;
    width: 430px;
    height: 430px;
    border: 1px solid #ffffff20;
    border-radius: 50%;
    bottom: -190px;
    right: -160px;
    box-shadow:
        0 0 0 45px #ffffff08,
        0 0 0 90px #ffffff05;
}

.institucional {
    position: relative;
    z-index: 1;
    max-width: 450px;
}

.logo {
    width: 73px;
    height: 73px;
    border: 1px solid #8290ad;
    border-radius: 18px;
    display: grid;
    place-items: center;
    font-size: 34px;
    margin-bottom: 26px;
}

.instituto {
    font-size: 12px;
    letter-spacing: 1px;
    color: #93c5fd;
    font-weight: 700;
    margin: 0;
}

.nombre {
    font-size: 42px;
    margin: 4px 0 13px;
}

.subtitulo {
    font-size: 18px;
    margin: 0 0 30px;
}

.descripcion {
    font-size: 15px;
    line-height: 1.9;
    color: #e2e8f0;
}

.pie {
    margin-top: 46px;
    font-size: 12px;
    color: #93c5fd;
}

.derecha {
    width: 48.8%;
    display: grid;
    place-items: center;
    padding: 48px 30px;
}

.formulario {
    width: 100%;
    max-width: 390px;
}

.bienvenida {
    font-size: 12px;
    letter-spacing: 1.2px;
    color: #64748b;
    font-weight: 700;
    margin: 0 0 5px;
}

.formulario h2 {
    font-size: 28px;
    margin: 0 0 10px;
}

.intro {
    font-size: 13px;
    color: #64748b;
    margin: 0 0 29px;
}

.grupo {
    margin-bottom: 19px;
}

.grupo label {
    display: block;
    font-size: 13px;
    font-weight: 650;
    margin-bottom: 7px;
}

.grupo select,
.grupo input {
    width: 100%;
    height: 44px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 0 12px;
    font-size: 13px;
    background: #fff;
    color: #0f172a;
}

.grupo select:focus,
.grupo input:focus {
    outline: none;
    border-color: #2563eb;
    box-shadow: 0 0 0 3px #dbeafe;
}

.boton {
    width: 100%;
    height: 44px;
    background: #1e3a8a;
    border: 0;
    border-radius: 6px;
    color: #fff;
    font-weight: 650;
    cursor: pointer;
}

.boton:hover {
    background: #2563eb;
}

.mensaje {
    padding: 12px;
    background: #fef2f2;
    color: #b91c1c;
    border: 1px solid #fecaca;
    border-radius: 6px;
    font-size: 13px;
    margin-bottom: 20px;
}

.nota {
    text-align: center;
    font-size: 11px;
    line-height: 1.6;
    color: #64748b;
    margin-top: 24px;
}

@media (max-width: 850px) {

    .contenedor {
        flex-direction: column;
    }

    .izquierda,
    .derecha {
        width: 100%;
    }

    .izquierda {
        padding: 40px 30px;
    }

    .nombre {
        font-size: 34px;
    }

    .derecha {
        padding: 45px 25px;
    }
}
</style>

</head>

<body>

<main class="contenedor">

    <!-- LADO IZQUIERDO -->

    <section class="izquierda">

        <div class="institucional">

            <div class="logo">✦</div>

            <p class="instituto">
                INSTITUTO NACIONAL
            </p>

            <h1 class="nombre">
                Albert Camus
            </h1>

            <h3 class="subtitulo">
                Control Escolar De Faltas
            </h3>

            <p class="descripcion">
                Sistema de Control de Faltas Escolares.
                Una herramienta institucional para
                registrar, consultar y dar seguimiento
                a las incidencias estudiantiles.
            </p>

            <p class="pie">
                Desarrollo de Software · Sección 3-1
            </p>

        </div>

    </section>

    <!-- LADO DERECHO -->

    <section class="derecha">

        <div class="formulario">

            <p class="bienvenida">
                BIENVENIDO DE NUEVO
            </p>

            <h2>Iniciar sesión</h2>

            <p class="intro">
                Ingresa tus credenciales para continuar.
            </p>

            <!-- MENSAJE DE ERROR -->

            <?php if ($mensaje !== ''): ?>

                <div class="mensaje" role="alert">
                    <?= htmlspecialchars(
                        $mensaje,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </div>

            <?php endif; ?>

            <!-- FORMULARIO LOGIN -->

            <form method="post">

                <div class="grupo">

                    <label for="rol">
                        Rol / Cargo Administrativo
                    </label>

                    <select
                        name="rol"
                        id="rol"
                        required
                    >

                        <option value="">
                            -- Seleccione su rol --
                        </option>

                        <?php foreach ($roles as $valor => $nombre): ?>

                            <option
                                value="<?= htmlspecialchars($valor, ENT_QUOTES, 'UTF-8') ?>"
                                <?= (($_POST['rol'] ?? '') === $valor) ? 'selected' : '' ?>
                            >
                                <?= htmlspecialchars($nombre, ENT_QUOTES, 'UTF-8') ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="grupo">

                    <label for="clave">
                        Contraseña
                    </label>

                    <input
                        type="password"
                        name="clave"
                        id="clave"
                        placeholder="Ingresa tu contraseña"
                        autocomplete="current-password"
                        required
                    >

                </div>

                <button class="boton" type="submit">
                    Iniciar sesión →
                </button>

            </form>

            <p class="nota">
                Acceso exclusivo para personal autorizado.
                Sistema de Control de Faltas Escolares.
            </p>

        </div>

    </section>

</main>

</body>
</html>
